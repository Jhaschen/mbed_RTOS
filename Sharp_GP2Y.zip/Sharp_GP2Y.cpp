#include "Sharp_GP2Y.h"
#include "math.h"

GP2Y::GP2Y(PinName DATA) :GP2YIn(DATA) {}

uint16_t GP2Y::getRange(void){
    
    double vin=(GP2YIn.read_u16()*0.0000503); // 16 Bit Digitalwert in Spannungwert umrechnen ( 3,3V / 65536 Schritte)
    double Abstand=11.056*(pow((vin),-0.95)); // Sapnnungsert in abstandswert in cm umwandeln
    
    if(Abstand > 30) // Messung auf max. 30 cm begrenzen
    {
       Abstand=30; 
        }
    
    return((uint16_t) Abstand);
    
    
    }