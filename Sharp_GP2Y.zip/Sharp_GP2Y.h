#ifndef GP2Y_H
#define GP2Y_H

#include "mbed.h"

class GP2Y {
    
public:
GP2Y(PinName DATA);

uint16_t  getRange(void); // Ausagbe Abtand in cm

protected:
AnalogIn GP2YIn;

};

#endif